# UK Visa Sponsor Checker（Chrome 插件原型）

在职位页面右下角显示一个小面板，告诉你：

1. **公司资质**：这家公司是否在英国 Home Office 的持牌担保雇主名单（Register of Worker and Temporary Worker licensed sponsors）中，是否包含 Skilled Worker 路线，评级是多少。
2. **JD 表述**：职位描述里是否写了"不提供签证担保"、"可以担保"或"必须已有英国工作权"，并把原句高亮出来。
3. **综合判断**：把两者合在一起给出一个红/黄/绿结论。

## 安装（开发者模式）

1. 解压 `uk-visa-sponsor-checker.zip`
2. Chrome 打开 `chrome://extensions`
3. 打开右上角 **开发者模式**
4. 点击 **加载已解压的扩展程序**，选择解压出来的 `uk-visa-sponsor-checker` 文件夹
5. 安装后插件会自动从 GOV.UK 下载最新名单（约 10MB，几秒钟）。点击工具栏里的插件图标可以看到名单日期和条目数。

Edge、Brave 等 Chromium 浏览器同样可用。

## 支持的网站

LinkedIn Jobs、Indeed（uk/com）、Glassdoor、Reed、Totaljobs、CV-Library，以及 Greenhouse、Lever、Ashby、Workable 这几个公司招聘系统的职位页。

其他网站：点击插件图标，手动输入公司名查询，或者粘贴 JD 文本分析。

## 工作原理

| 部分 | 文件 | 说明 |
|---|---|---|
| 名单同步 | `background.js` | 通过 GOV.UK Content API 找到最新 CSV 链接并下载；之后每 24 小时检查一次，链接变了才重新下载 |
| 公司名匹配 | `lib/matcher.js` | 去掉 Ltd / Limited / PLC / UK / Group 等后缀后精确匹配；识别 "T/A"（trading as）别名；匹配不上时给出名称相近的候选 |
| JD 识别 | `lib/detector.js` | 按句子分类：明确不担保 > 可担保 > 要求已有工作权 > 仅提及 |
| 页面读取 | `content/sites.js` | 各网站的选择器，加上通用的 schema.org JobPosting 数据 |
| 面板 | `content/content.js` | Shadow DOM 隔离样式，支持折叠，支持手动修正公司名 |

所有数据保存在你本地浏览器里，插件不会把你浏览的页面上传到任何服务器。

## 已知局限

- **名单只证明公司有执照**，不代表这个岗位愿意担保，也不保证薪资达到 Skilled Worker 门槛。
- **公司名不一致**：名单里是注册法律名称，招聘网站上常是品牌名（例如 Deliveroo 的法律主体是 Roofoods Ltd），这种情况会显示"未找到"。面板里可以手动输入法律名称再查。
- **网站改版**：LinkedIn、Indeed 等会改页面结构，读不到公司名时需要更新 `content/sites.js` 里的选择器。
- **JD 识别基于规则**，少数措辞会判断错，所以面板总会把原句列出来供你自己判断。以后可以换成 LLM 判断。

## 测试

```bash
node tests/test.js
```

## 下一步可以做

- 品牌名 ↔ 法律名称的别名表（可以从 Companies House API 补充）
- 读取 JD 里的薪资，对比 Skilled Worker 薪资门槛
- 在 LinkedIn 搜索结果列表里直接给每个职位打标签
- 用 LLM 替代规则做 JD 判断
