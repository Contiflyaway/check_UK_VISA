// Run: node tests/test.js
const assert = require('assert');
const { parseCSV } = require('../lib/csv.js');
const M = require('../lib/matcher.js');
const D = require('../lib/detector.js');

let pass = 0, fail = 0;
function t(name, fn) {
  try { fn(); pass++; } catch (e) { fail++; console.log('FAIL', name, '\n  ', e.message); }
}

// ---- CSV + register (same columns as the GOV.UK file) ----
const csv = '﻿"Organisation Name","Town/City","County","Type & Rating","Route"\r\n' + [
  '"Monzo Bank Ltd","London","","Worker (A rating)","Skilled Worker"',
  '"Google UK Limited","London","","Worker (A rating)","Skilled Worker"',
  '"Google UK Limited","London","","Worker (A rating)","Global Business Mobility: Senior or Specialist Worker"',
  '"Deloitte LLP","London","Greater London","Worker (A rating)","Skilled Worker"',
  '"J.P. Morgan Europe Limited","London","","Worker (A rating)","Skilled Worker"',
  '"Bloggs Ltd T/A Joe\'s Cafe","Leeds","West Yorkshire","Worker (A rating)","Skilled Worker"',
  '"Acme, ""Widgets"" & Co Ltd","Bristol","","Temporary Worker (A rating)","Creative Worker"',
  '"Transport for London","London","","Worker (A rating)","Skilled Worker"'
].join('\r\n') + '\r\n';

const rows = parseCSV(csv);
t('csv parses header + rows', () => assert.strictEqual(rows.length, 9));
t('csv handles quotes and commas', () => assert.strictEqual(rows[7][0], 'Acme, "Widgets" & Co Ltd'));

const entries = M.buildEntries(rows);
t('duplicate org rows merged', () => assert.strictEqual(entries.length, 7));
const google = entries.find(e => e[0] === 'Google UK Limited');
t('routes merged', () => assert.ok(/Skilled Worker/.test(google[4]) && /Global Business/.test(google[4])));

const idx = M.buildIndex(entries);
const look = q => M.lookup(idx, q);

t('normalize suffixes', () => assert.strictEqual(M.normalizeName('Google UK Limited'), 'google'));
t('normalize J.P. Morgan', () => assert.strictEqual(M.normalizeName('J.P. Morgan'), 'jp morgan'));
t('exact: Google', () => { const r = look('Google'); assert.strictEqual(r.status, 'confirmed'); assert.ok(r.matches[0].skilledWorker); });
t('exact: Deloitte', () => assert.strictEqual(look('Deloitte').status, 'confirmed'));
t('exact: JPMorgan via Europe suffix', () => assert.strictEqual(look('J.P. Morgan').status, 'confirmed'));
t('possible: Monzo -> Monzo Bank', () => { const r = look('Monzo'); assert.strictEqual(r.status, 'possible'); assert.strictEqual(r.matches[0].name, 'Monzo Bank Ltd'); });
t('possible: Deloitte Digital -> Deloitte', () => assert.strictEqual(look('Deloitte Digital').status, 'possible'));
t('trading-as alias', () => assert.strictEqual(look("Joe's Cafe").status, 'confirmed'));
t('Transport for London kept intact', () => assert.strictEqual(look('Transport for London').status, 'confirmed'));
t('not found', () => assert.strictEqual(look('Nonexistent Startup').status, 'not_found'));
t('creative-only route flagged', () => assert.strictEqual(look('Acme Widgets').matches.length ? look('Acme Widgets').matches[0].skilledWorker : false, false));
t('no data', () => assert.strictEqual(M.lookup(null, 'x').status, 'no_data'));

// ---- detector ----
const cases = [
  ['We are unable to offer visa sponsorship for this role.', 'no_sponsor'],
  ['Unfortunately we do not provide visa sponsorship.', 'no_sponsor'],
  ['We do not provide visa', 'no_sponsor'],
  ['Please note: this position does not offer sponsorship.', 'no_sponsor'],
  ['Visa sponsorship is not available for this position.', 'no_sponsor'],
  ['Candidates who need sponsorship will not be considered.', 'no_sponsor'],
  ['Applicants requiring visa sponsorship cannot be considered at this time.', 'no_sponsor'],
  ["We can't sponsor work visas.", 'no_sponsor'],
  ['No visa sponsorship available.', 'no_sponsor'],
  ['Visa sponsorship: No', 'no_sponsor'],
  ['You must be able to work in the UK without the need for sponsorship.', 'no_sponsor'],
  ['Visa sponsorship is available for this role.', 'sponsor_offered'],
  ['We are happy to sponsor Skilled Worker visas.', 'sponsor_offered'],
  ['Candidates who require sponsorship are welcome to apply.', 'sponsor_offered'],
  ['Visa sponsorship: Yes', 'sponsor_offered'],
  ['We offer relocation support and sponsorship is available.', 'sponsor_offered'],
  ['You must have the right to work in the UK.', 'rtw_required'],
  ['Applicants must hold a full UK right to work.', 'rtw_required'],
  ['This role requires SC clearance.', 'rtw_required'],
  ['Proof of right to work will be checked before your start date.', 'mentioned'],
  ['We are a fast-growing fintech building payments infrastructure.', 'not_mentioned'],
  ['Visa sponsorship is available. You must have the right to work in the UK.', 'mixed'],
  ['We sponsor visas for engineers. However we are unable to sponsor for this role.', 'no_sponsor']
];
for (const [text, want] of cases) {
  t('detect: ' + text, () => assert.strictEqual(D.analyze(text).verdict, want));
}

t('evidence sorted negative first', () => {
  const r = D.analyze('We sponsor visas for engineers. However we are unable to sponsor for this role.');
  assert.strictEqual(r.evidence[0].type, 'negative');
});
t('multi-line JD with bullets', () => {
  const jd = 'About us\n• Competitive salary\n• Hybrid working\nPlease note we are not able to provide sponsorship\n';
  assert.strictEqual(D.analyze(jd).verdict, 'no_sponsor');
});

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
