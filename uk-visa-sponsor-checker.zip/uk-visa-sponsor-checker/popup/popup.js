const $ = id => document.getElementById(id);

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

function send(msg) {
  return new Promise(resolve => chrome.runtime.sendMessage(msg, res => resolve(res || {})));
}

function fmtTime(ts) {
  return ts ? new Date(ts).toLocaleString('zh-CN', { hour12: false }) : '—';
}

async function loadStatus() {
  const s = await send({ type: 'status' });
  const box = $('status');
  box.replaceChildren();
  if (s.meta && s.meta.count) {
    box.append(
      el('div', null, `已载入 ${s.meta.count.toLocaleString()} 家持牌雇主`),
      el('div', 'muted', `名单日期：${s.meta.registerDate || '未知'}`),
      el('div', 'muted', `上次检查：${fmtTime(s.meta.lastChecked)}`)
    );
  } else if (s.refreshing) {
    box.append(el('div', null, '正在下载名单（约 10MB）…'));
  } else {
    box.append(el('div', null, '尚未下载名单，请点击下方按钮。'));
  }
  if (s.error) box.append(el('div', 'error', '上次更新失败：' + s.error));
}

$('refresh').addEventListener('click', async () => {
  const btn = $('refresh');
  btn.disabled = true;
  btn.textContent = '下载中…';
  const r = await send({ type: 'refresh' });
  btn.disabled = false;
  btn.textContent = '立即从 GOV.UK 更新';
  await loadStatus();
  if (!r.ok) $('status').append(el('div', 'error', r.error || '更新失败'));
});

const LABELS = {
  confirmed: ['good', '✅ 在担保名单中'],
  possible: ['warn', '🟡 找到名称相近的公司，请核对'],
  not_found: ['bad', '❌ 未在担保名单中找到'],
  no_data: ['neutral', '名单尚未下载']
};

$('lookupForm').addEventListener('submit', async e => {
  e.preventDefault();
  const name = $('company').value.trim();
  const out = $('lookupResult');
  out.replaceChildren();
  if (!name) return;
  const r = await send({ type: 'lookup', name });
  const [cls, label] = LABELS[r.status] || LABELS.no_data;
  out.append(el('div', 'verdict ' + cls, label));
  for (const m of r.matches || []) {
    const d = el('div', 'match');
    d.append(
      el('div', null, m.name),
      el('div', 'muted', [m.town, m.county].filter(Boolean).join(', ')),
      el('div', 'muted', `${m.routes || '—'}${m.ratings ? ' · ' + m.ratings : ''}`)
    );
    out.append(d);
  }
});

$('analyze').addEventListener('click', () => {
  const out = $('jdResult');
  out.replaceChildren();
  const r = VisaDetector.analyze($('jd').value);
  out.append(el('div', 'verdict ' + r.level, r.label));
  for (const ev of r.evidence) out.append(el('div', 'ev ' + ev.type, ev.sentence));
});

loadStatus();
