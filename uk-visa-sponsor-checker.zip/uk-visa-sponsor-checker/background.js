// Service worker: downloads the Home Office "Register of Worker and Temporary Worker
// licensed sponsors" from GOV.UK, caches it, refreshes daily, and answers lookups.
importScripts('lib/csv.js', 'lib/matcher.js');

const GOVUK_API = 'https://www.gov.uk/api/content/government/publications/register-of-licensed-sponsors-workers';
const GOVUK_PAGE = 'https://www.gov.uk/government/publications/register-of-licensed-sponsors-workers';
const ALARM = 'daily-register-refresh';

let index = null;        // in-memory lookup index
let loading = null;      // promise while loading from storage
let refreshing = null;   // promise while downloading
let lastError = null;

// ---------- locating the latest CSV ----------
async function findLatestCsv() {
  try {
    const res = await fetch(GOVUK_API, { cache: 'no-store' });
    if (!res.ok) throw new Error('GOV.UK API HTTP ' + res.status);
    const json = await res.json();
    const atts = (json.details && json.details.attachments) || [];
    const csv = atts.find(a => /csv/i.test(a.content_type || '') || /\.csv$/i.test(a.url || ''));
    if (csv) {
      return { url: csv.url, filename: csv.filename || csv.url.split('/').pop(), publishedAt: json.public_updated_at || null };
    }
  } catch (e) {
    console.warn('[SponsorChecker] API lookup failed, falling back to page:', e);
  }
  // Fallback: scrape the publication page for the CSV link.
  const res = await fetch(GOVUK_PAGE, { cache: 'no-store' });
  if (!res.ok) throw new Error('GOV.UK 页面 HTTP ' + res.status);
  const html = await res.text();
  const m = html.match(/https:\/\/assets\.publishing\.service\.gov\.uk\/[^"'\s>]+\.csv/i);
  if (!m) throw new Error('在 GOV.UK 页面上找不到担保名单 CSV 链接');
  return { url: m[0], filename: decodeURIComponent(m[0].split('/').pop()), publishedAt: null };
}

function registerDate(filename) {
  const m = String(filename || '').match(/(\d{4}-\d{2}-\d{2})/);
  return m ? m[1] : null;
}

// ---------- download / cache ----------
async function refresh(force = false) {
  if (refreshing) return refreshing;
  refreshing = (async () => {
    try {
      const latest = await findLatestCsv();
      const { meta } = await chrome.storage.local.get('meta');
      if (!force && meta && meta.url === latest.url && index) {
        await chrome.storage.local.set({ meta: { ...meta, lastChecked: Date.now() } });
        lastError = null;
        return { updated: false };
      }
      const res = await fetch(latest.url, { cache: 'no-store' });
      if (!res.ok) throw new Error('下载名单失败 HTTP ' + res.status);
      const text = await res.text();
      const entries = SponsorMatcher.buildEntries(SponsorCSV.parseCSV(text));
      if (entries.length < 1000) throw new Error('名单条目异常偏少（' + entries.length + '），已保留旧数据');
      const newMeta = {
        url: latest.url,
        filename: latest.filename,
        registerDate: registerDate(latest.filename),
        publishedAt: latest.publishedAt,
        count: entries.length,
        downloadedAt: Date.now(),
        lastChecked: Date.now()
      };
      await chrome.storage.local.set({ entries, meta: newMeta });
      index = SponsorMatcher.buildIndex(entries);
      lastError = null;
      return { updated: true };
    } catch (e) {
      lastError = String(e && e.message || e);
      console.error('[SponsorChecker] refresh failed:', e);
      throw e;
    } finally {
      refreshing = null;
    }
  })();
  return refreshing;
}

async function ensureIndex() {
  if (index) return index;
  if (!loading) {
    loading = (async () => {
      const { entries } = await chrome.storage.local.get('entries');
      if (entries && entries.length) {
        index = SponsorMatcher.buildIndex(entries);
      } else {
        await refresh(true).catch(() => {});
      }
      return index;
    })().finally(() => { loading = null; });
  }
  return loading;
}

// ---------- scheduling ----------
function scheduleDaily() {
  chrome.alarms.get(ALARM, a => {
    if (!a) chrome.alarms.create(ALARM, { delayInMinutes: 1, periodInMinutes: 24 * 60 });
  });
}

chrome.runtime.onInstalled.addListener(() => {
  scheduleDaily();
  refresh(true).catch(() => {});
});
chrome.runtime.onStartup.addListener(() => {
  scheduleDaily();
  ensureIndex();
});
chrome.alarms.onAlarm.addListener(a => {
  if (a.name === ALARM) ensureIndex().then(() => refresh(false)).catch(() => {});
});

// ---------- messaging ----------
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    switch (msg && msg.type) {
      case 'lookup': {
        const idx = await ensureIndex();
        return SponsorMatcher.lookup(idx, msg.name || '');
      }
      case 'status': {
        const { meta } = await chrome.storage.local.get('meta');
        return { meta: meta || null, ready: !!index || !!(meta && meta.count), refreshing: !!refreshing, error: lastError };
      }
      case 'refresh': {
        try {
          const r = await refresh(true);
          const { meta } = await chrome.storage.local.get('meta');
          return { ok: true, ...r, meta };
        } catch (e) {
          return { ok: false, error: String(e && e.message || e) };
        }
      }
      default:
        return { error: 'unknown message' };
    }
  })().then(sendResponse, e => sendResponse({ error: String(e) }));
  return true; // async response
});
