// Per-site extractors: find the company name and job description on the current page.
// Job sites change their markup often — if a site stops working, update its selectors here.
(function (root) {
  const SITES = [
    {
      id: 'linkedin',
      host: /(^|\.)linkedin\.com$/,
      path: /^\/jobs\//,
      custom: linkedinFallback,
      company: [
        '.job-details-jobs-unified-top-card__company-name a',
        '.job-details-jobs-unified-top-card__company-name',
        '.jobs-unified-top-card__company-name a',
        '.jobs-unified-top-card__company-name',
        '.topcard__org-name-link',
        'a[data-tracking-control-name="public_jobs_topcard-org-name"]',
        '.jobs-details__main-content a[href*="/company/"]'
      ],
      description: [
        '#job-details',
        '.jobs-description__content',
        '.jobs-box__html-content',
        '.show-more-less-html__markup',
        '.description__text'
      ]
    },
    {
      id: 'indeed',
      host: /(^|\.)indeed\.(com|co\.uk)$/,
      company: [
        '[data-testid="inlineHeader-companyName"] a',
        '[data-testid="inlineHeader-companyName"]',
        '[data-company-name="true"]',
        '.jobsearch-CompanyInfoContainer a',
        '.jobsearch-InlineCompanyRating > div:first-child'
      ],
      description: ['#jobDescriptionText', '.jobsearch-jobDescriptionText']
    },
    {
      id: 'glassdoor',
      host: /(^|\.)glassdoor\.(com|co\.uk)$/,
      company: [
        '[data-test="employer-name"]',
        '[data-test="employerName"]',
        '[class*="EmployerProfile_employerName"]',
        '[class*="EmployerProfile_profileContainer"] h4'
      ],
      description: [
        '[class*="JobDetails_jobDescription"]',
        '[data-test="jobDescriptionContent"]',
        '.jobDescriptionContent'
      ]
    },
    {
      id: 'reed',
      host: /(^|\.)reed\.co\.uk$/,
      company: ['[itemprop="hiringOrganization"] [itemprop="name"]', '[data-qa="job-posted-by"] a', '.posted-by a'],
      description: ['[itemprop="description"]', '[data-qa="job-description"]', '.description']
    },
    {
      id: 'ats-slug',
      // Greenhouse / Lever / Ashby / Workable: company is usually the first path segment.
      host: /(^|\.)(greenhouse\.io|lever\.co|ashbyhq\.com|workable\.com)$/,
      company: [],
      description: ['#content', '.posting-page', '[class*="_descriptionText"]', 'main'],
      slugCompany: true
    }
  ];

  // LinkedIn's new job UI uses obfuscated class names, so fall back to structure:
  // company = first /company/ link in the right-hand detail pane,
  // description = the block under the "About the job" heading.
  function linkedinFallback() {
    const vw = window.innerWidth;
    const links = Array.from(document.querySelectorAll('a[href*="/company/"]'))
      .filter(a => {
        const t = text(a);
        if (!t || t.length > 80 || /\n/.test(t)) return false;
        const r = a.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && r.left > vw * 0.3;
      })
      .sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
    const company = links.length ? text(links[0]) : '';

    let description = '';
    const heading = document.evaluate(
      "//*[normalize-space(text())='About the job']",
      document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
    ).singleNodeValue;
    if (heading) {
      let p = heading.parentElement;
      while (p && text(p).length < 300 && p !== document.body) p = p.parentElement;
      if (p && p !== document.body) description = text(p);
    }
    return { company, description };
  }

  function text(el) {
    return el ? (el.innerText || el.textContent || '').trim() : '';
  }

  function firstText(selectors) {
    for (const sel of selectors) {
      let el;
      try { el = document.querySelector(sel); } catch (_) { continue; }
      const t = text(el);
      if (t) return t;
    }
    return '';
  }

  function htmlToText(html) {
    const doc = new DOMParser().parseFromString(String(html || ''), 'text/html');
    doc.querySelectorAll('br, p, li, div, h1, h2, h3, h4').forEach(n => n.append('\n'));
    return (doc.body && doc.body.textContent || '').trim();
  }

  // schema.org JobPosting — present on many job boards and ATS pages.
  function fromJsonLd() {
    for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
      let data;
      try { data = JSON.parse(s.textContent); } catch (_) { continue; }
      const items = [].concat(data, data && data['@graph'] || []).flat();
      for (const it of items) {
        if (!it || typeof it !== 'object') continue;
        const type = [].concat(it['@type'] || []);
        if (!type.includes('JobPosting')) continue;
        const org = it.hiringOrganization;
        const company = typeof org === 'string' ? org : (org && org.name) || '';
        return { company: String(company).trim(), description: htmlToText(it.description) };
      }
    }
    return null;
  }

  function slugCompany() {
    const seg = location.pathname.split('/').filter(Boolean)[0] || '';
    if (!seg || /^(jobs?|embed|v\d)$/i.test(seg)) return '';
    return decodeURIComponent(seg).replace(/[-_]+/g, ' ');
  }

  function cleanCompany(s) {
    return String(s || '')
      .split('\n')[0]
      .replace(/\s*\d(\.\d)?\s*★.*$/, '')   // Glassdoor "Acme 4.2★"
      .replace(/\s*[·|•].*$/, '')
      .trim();
  }

  function extract() {
    const site = SITES.find(s => s.host.test(location.hostname));
    if (site && site.path && !site.path.test(location.pathname)) return null;
    let company = site ? firstText(site.company) : '';
    let description = site ? firstText(site.description) : '';

    if (site && site.custom && (!company || description.length < 200)) {
      const c = site.custom();
      if (!company) company = c.company;
      if (description.length < 200 && c.description) description = c.description;
    }

    const ld = fromJsonLd();
    if (ld) {
      if (!company) company = ld.company;
      if (!description || description.length < 200) description = ld.description || description;
    }
    if (!company && site && site.slugCompany) company = slugCompany();

    return {
      site: site ? site.id : 'generic',
      company: cleanCompany(company),
      description: description.slice(0, 40000)
    };
  }

  root.SponsorSites = { extract };
})(globalThis);
