// Injects a floating panel on job pages showing:
//  1) whether the company is on the Home Office licensed-sponsor register
//  2) what the job description says about visa sponsorship
(function () {
  if (window.__sponsorCheckerLoaded) return;
  window.__sponsorCheckerLoaded = true;

  const STYLE = `
    :host { all: initial; }
    .panel { position: fixed; right: 16px; bottom: 16px; z-index: 2147483646; width: 340px;
      max-height: 70vh; overflow: auto; background: #fff; color: #1f2328; border: 1px solid #d0d7de;
      border-radius: 12px; box-shadow: 0 8px 28px rgba(0,0,0,.18);
      font: 13px/1.45 -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif; }
    .head { display: flex; align-items: center; gap: 8px; padding: 10px 12px; border-bottom: 1px solid #eaeef2;
      position: sticky; top: 0; background: #fff; cursor: pointer; }
    .head .title { font-weight: 600; flex: 1; }
    .dot { width: 10px; height: 10px; border-radius: 50%; flex: none; }
    .good { background: #1a7f37; } .warn { background: #bf8700; } .bad { background: #cf222e; } .neutral { background: #8c959f; }
    .btn { border: 1px solid #d0d7de; background: #f6f8fa; border-radius: 6px; padding: 2px 8px; cursor: pointer; font: inherit; color: inherit; }
    .body { padding: 10px 12px 12px; }
    .summary { padding: 8px 10px; border-radius: 8px; margin-bottom: 10px; font-weight: 600; }
    .summary.good { background: #dafbe1; color: #116329; } .summary.warn { background: #fff8c5; color: #7d4e00; }
    .summary.bad { background: #ffebe9; color: #a40e26; } .summary.neutral { background: #f6f8fa; color: #57606a; }
    .sec { margin-top: 10px; }
    .sec h4 { margin: 0 0 4px; font-size: 12px; color: #57606a; font-weight: 600; text-transform: none; }
    .row { display: flex; gap: 6px; align-items: flex-start; }
    .row .dot { margin-top: 5px; }
    .muted { color: #57606a; font-size: 12px; }
    .match { margin: 4px 0 0 16px; padding: 4px 6px; background: #f6f8fa; border-radius: 6px; font-size: 12px; }
    .ev { margin: 6px 0 0; padding: 6px 8px; border-left: 3px solid #d0d7de; background: #f6f8fa; border-radius: 4px; font-size: 12px; }
    .ev.negative { border-color: #cf222e; } .ev.positive { border-color: #1a7f37; } .ev.rtw { border-color: #bf8700; }
    mark { background: #fff1a8; color: inherit; padding: 0 1px; }
    .fix { display: flex; gap: 6px; margin-top: 6px; }
    .fix input { flex: 1; min-width: 0; border: 1px solid #d0d7de; border-radius: 6px; padding: 3px 6px; font: inherit; }
    .collapsed .body { display: none; }
    .collapsed { width: auto; }
    @media (prefers-color-scheme: dark) {
      .panel, .head { background: #161b22; color: #e6edf3; border-color: #30363d; }
      .head { border-color: #30363d; }
      .btn, .fix input { background: #21262d; border-color: #30363d; color: #e6edf3; }
      .match, .ev, .summary.neutral { background: #21262d; color: #c9d1d9; }
      .muted, .sec h4 { color: #8b949e; }
      .summary.good { background: #033a16; color: #7ee787; } .summary.warn { background: #3d2e00; color: #f2cc60; }
      .summary.bad { background: #490202; color: #ffa198; }
      mark { background: #5a4a00; }
    }
  `;

  function el(tag, attrs, ...children) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (k === 'class') e.className = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v);
    }
    for (const c of children.flat()) if (c != null) e.append(c);
    return e;
  }

  function highlight(sentence, match) {
    const i = match ? sentence.toLowerCase().indexOf(match.toLowerCase()) : -1;
    if (i < 0) return [sentence];
    return [sentence.slice(0, i), el('mark', {}, sentence.slice(i, i + match.length)), sentence.slice(i + match.length)];
  }

  // ---------- panel ----------
  const host = el('div', { id: 'uk-sponsor-checker' });
  const shadow = host.attachShadow({ mode: 'open' });
  shadow.append(el('style', {}, STYLE));
  const panel = el('div', { class: 'panel' });
  shadow.append(panel);
  let collapsed = false;
  try {
    chrome.storage.local.get('panelCollapsed', r => { collapsed = !!r.panelCollapsed; panel.classList.toggle('collapsed', collapsed); });
  } catch (_) {}

  function toggle() {
    collapsed = !collapsed;
    panel.classList.toggle('collapsed', collapsed);
    try { chrome.storage.local.set({ panelCollapsed: collapsed }); } catch (_) {}
  }

  const COMPANY_TEXT = {
    confirmed: { level: 'good', label: '在英国持牌担保雇主名单中' },
    possible: { level: 'warn', label: '名单中有名称相近的公司，请核对' },
    not_found: { level: 'bad', label: '未在担保名单中找到' },
    no_data: { level: 'neutral', label: '担保名单尚未下载（点击插件图标更新）' },
    unknown: { level: 'neutral', label: '未识别到公司名' }
  };

  function overall(company, jd) {
    const c = company.status, v = jd.verdict;
    if (v === 'no_sponsor') return { level: 'bad', text: '🔴 该岗位很可能不提供签证担保' };
    if (c === 'confirmed' && v === 'sponsor_offered') return { level: 'good', text: '🟢 公司有担保资质，且 JD 表示可担保' };
    if (c === 'confirmed' && company.matches.some(m => m.skilledWorker) && v === 'rtw_required')
      return { level: 'warn', text: '🟡 公司有资质，但该岗位要求已有工作权' };
    if (c === 'confirmed' && company.matches.some(m => m.skilledWorker))
      return { level: v === 'mixed' ? 'warn' : 'good', text: '🟢 公司有 Skilled Worker 担保资质，岗位未明确，建议向 HR 确认' };
    if (c === 'confirmed') return { level: 'warn', text: '🟡 公司在名单中，但不含 Skilled Worker 路线' };
    if (c === 'possible') return { level: 'warn', text: '🟡 可能有资质，请核对下方名单中的法律名称' };
    if (v === 'sponsor_offered') return { level: 'warn', text: '🟡 JD 说可担保，但名单中未匹配到公司（可能是法律名称不同）' };
    if (c === 'not_found') return { level: 'bad', text: '🔴 未找到担保资质' };
    return { level: 'neutral', text: '⚪ 信息不足' };
  }

  function render(state) {
    const { info, company, jd } = state;
    const ov = overall(company, jd);
    const ct = COMPANY_TEXT[company.status] || COMPANY_TEXT.unknown;

    const fixInput = el('input', { type: 'text', placeholder: '公司名不对？手动输入后回车', value: state.manualName || '' });
    const runFix = () => { const v = fixInput.value.trim(); if (v) { state.manualName = v; lookupAndRender(state); } };
    fixInput.addEventListener('keydown', e => { if (e.key === 'Enter') runFix(); });

    panel.replaceChildren(
      el('div', { class: 'head', onclick: toggle },
        el('span', { class: 'dot ' + ov.level }),
        el('span', { class: 'title' }, 'UK 签证担保检查'),
        el('button', { class: 'btn', title: '折叠/展开' }, collapsed ? '展开' : '折叠')
      ),
      el('div', { class: 'body' },
        el('div', { class: 'summary ' + ov.level }, ov.text),

        el('div', { class: 'sec' },
          el('h4', {}, '公司资质（Home Office 担保名单）'),
          el('div', { class: 'row' }, el('span', { class: 'dot ' + ct.level }),
            el('div', {}, el('div', {}, ct.label),
              el('div', { class: 'muted' }, '页面公司名：' + (state.manualName || info.company || '（未识别）')))),
          company.matches.slice(0, 4).map(m => el('div', { class: 'match' },
            el('div', {}, el('b', {}, m.name)),
            el('div', { class: 'muted' }, [m.town, m.county].filter(Boolean).join(', ')),
            el('div', { class: 'muted' }, (m.routes || '—') + (m.ratings ? ' · ' + m.ratings : ''))
          )),
          el('div', { class: 'fix' }, fixInput, el('button', { class: 'btn', onclick: runFix }, '查询'))
        ),

        el('div', { class: 'sec' },
          el('h4', {}, '职位描述中的签证表述'),
          el('div', { class: 'row' }, el('span', { class: 'dot ' + jd.level }), el('div', {}, jd.label)),
          jd.evidence.slice(0, 5).map(e => el('div', { class: 'ev ' + e.type }, highlight(e.sentence, e.match))),
          info.description ? null : el('div', { class: 'muted' }, '未读取到职位描述，可在插件弹窗里粘贴 JD 分析')
        ),

        el('div', { class: 'muted', style: 'margin-top:10px' },
          '结果仅供参考：名单只说明公司持有担保执照，具体岗位是否担保以雇主为准。')
      )
    );
    panel.classList.toggle('collapsed', collapsed);
    if (!host.isConnected) document.documentElement.append(host);
  }

  function lookupAndRender(state) {
    const name = state.manualName || state.info.company;
    if (!name) {
      state.company = { status: 'unknown', matches: [] };
      render(state);
      return;
    }
    try {
      chrome.runtime.sendMessage({ type: 'lookup', name }, res => {
        if (chrome.runtime.lastError || !res) res = { status: 'no_data', matches: [] };
        state.company = res;
        render(state);
      });
    } catch (_) {
      // Extension was reloaded; this old content script is orphaned.
    }
  }

  // ---------- page watching ----------
  let lastKey = '';
  function check() {
    const info = SponsorSites.extract();
    if (!info) { if (host.isConnected) host.remove(); lastKey = ''; return; } // left the jobs section
    const looksLikeJob = /currentJobId=|\/jobs\/view\/|viewjob|\/job\/|\/jobs\/[^/?#]+/i.test(location.href);
    if (!info.company && info.description.length < 100 && !looksLikeJob) return; // not a job page
    const key = location.href + '|' + info.company + '|' + info.description.length + '|' + info.description.slice(0, 120);
    if (key === lastKey) return;
    lastKey = key;
    const state = { info, jd: VisaDetector.analyze(info.description), company: { status: 'no_data', matches: [] } };
    lookupAndRender(state);
  }

  let timer = null;
  const schedule = () => { clearTimeout(timer); timer = setTimeout(check, 700); };
  new MutationObserver(muts => {
    if (muts.every(m => host.contains(m.target) || m.target === host)) return;
    schedule();
  }).observe(document.body, { childList: true, subtree: true, characterData: true });
  let lastUrl = location.href;
  setInterval(() => { if (location.href !== lastUrl) { lastUrl = location.href; schedule(); } }, 1000);
  schedule();
})();
